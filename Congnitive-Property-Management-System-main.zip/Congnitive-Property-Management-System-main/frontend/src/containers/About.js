import React from "react";
import "./About.css";

const About = () => {
  return (
    <div className="about-container">
      <div className="about-content">
        <h1 className="about-title">About Our Property Management System</h1>
        <p className="about-text">
          Our Property Management System is designed to make managing real estate
          effortless. From listing properties to managing tenants, leases, and
          payments — everything is streamlined in one place.
        </p>
        <p className="about-text">
          Built with a powerful <strong>Python (Django)</strong> backend and a
          dynamic <strong>React</strong> frontend, this platform ensures fast,
          secure, and user-friendly property management for agencies and
          landlords alike.
        </p>

        <div className="about-features">
          <div className="feature-card">
            <h3>🏠 Property Listings</h3>
            <p>
              Easily add, edit, and search property listings with real-time data
              and photo uploads.
            </p>
          </div>
          <div className="feature-card">
            <h3>👨‍💼 Tenant Management</h3>
            <p>
              Keep track of your tenants, lease agreements, and contact details
              in one organized system.
            </p>
          </div>
          <div className="feature-card">
            <h3>📊 Reports & Analytics</h3>
            <p>
              Get insights into occupancy rates, rent collection, and property
              performance through clean visual reports.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
