import React from "react";
import "./Home.css";
import {reactRouterDom, navigator} from "react-router-dom";


const Home = () => {
    function navigateTo(){
    }
  return (
    <div className="home-container">
      <header className="home-header">
        <h1 className="home-title">Welcome to Property Management System</h1>
        <p className="home-subtitle">
          Manage properties, tenants, and leases efficiently — all in one place.
        </p>
        <div className="home-buttons">
          <button className="btn primary">Get Started</button>
          <button className="btn secondary">Learn More</button>
        </div>
      </header>
    </div>
  );
};

export default Home;
