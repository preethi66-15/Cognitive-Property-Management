import React, { useState, useEffect } from "react";
import axios from "axios";
import Card from "../components/Card";
import "./Listings.css";

const Listings = () => {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch listings when component mounts
  useEffect(() => {
    const fetchListings = async () => {
      try {
        const res = await axios.get(`${process.env.REACT_APP_API_URL}/api/listings/`);
        setListings(res.data);
      } catch (err) {
        console.error("Error fetching listings:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchListings();
  }, []);

  return (
    <div className="listings-page">
      <h1 className="listings-title">Available Properties</h1>

      {loading ? (
        <div className="loader">Loading listings...</div>
      ) : listings.length === 0 ? (
        <p className="no-listings">No properties available at the moment.</p>
      ) : (
        <div className="listings-grid">
          {listings.map((listing) => (
            <Card
              key={listing.id}
              title={listing.title}
              address={listing.address}
              city={listing.city}
              state={listing.state}
              price={listing.price}
              sale_type={listing.sale_type}
              home_type={listing.home_type}
              bedrooms={listing.bedrooms}
              bathrooms={listing.bathrooms}
              sqft={listing.sqft}
              photo_main={listing.photo_main}
              slug={listing.slug}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default Listings;
