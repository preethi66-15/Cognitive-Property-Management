import React from "react";
import "./Contact.css";

const Contact = () => {
  const teamMembers = [
    {
      name: "Abdul Rehman",
      role: "Backend Developer",
      tech: "Python / Django",
      email: "abdul.rehman@example.com",
    },
    {
      name: "Preethi",
      role: "Frontend Developer",
      tech: "React / JavaScript",
      email: "sarah.khan@example.com",
    },
    {
      name: "Sai Teja",
      role: "UI/UX Designer",
      tech: "Figma / Photoshop",
      email: "ali.raza@example.com",
    },
    {
      name: "Uma Maheshwara rao",
      role: "Project Manager",
      tech: "Agile / Scrum",
      email: "mariam.ahmed@example.com",
    },
  ];

  return (
    <div className="contact-container">
      <h1 className="contact-title">Meet the Team</h1>
      <p className="contact-subtitle">
        We are a passionate team dedicated to building a smooth property
        management experience.
      </p>

      <div className="team-grid">
        {teamMembers.map((member, index) => (
          <div className="team-card" key={index}>
            <div className="team-avatar">
              <span>{member.name.charAt(0)}</span>
            </div>
            <h3 className="team-name">{member.name}</h3>
            <p className="team-role">{member.role}</p>
            <p className="team-tech">{member.tech}</p>
            <a className="team-email" href={`mailto:${member.email}`}>
              {member.email}
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Contact;
